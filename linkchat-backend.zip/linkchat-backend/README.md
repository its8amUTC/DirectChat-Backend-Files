# LinkChat backend starter

Node.js + Express + Socket.IO + PostgreSQL backend for a Wix Headless chat frontend.

## Included

- Verified bearer-token authentication for REST and Socket.IO
- Direct conversations and membership checks
- Persisted messages and conversation history
- Real-time `message:new` delivery
- CORS allowlist, Helmet headers, bounded request/message sizes
- Docker Compose PostgreSQL + API starter

## 1. Requirements

- Node.js 20+ and npm, or Docker Compose
- PostgreSQL 14+
- A public HTTPS origin for production
- The exact Wix-issued access token that your frontend can obtain and send to this backend

## 2. Configure authentication before use

This starter deliberately has **no insecure development bypass**. Authenticated routes return 401 until token verification is configured.

Copy `.env.example` to `.env` and set:

- `JWT_JWKS_URL`: HTTPS URL of the JSON Web Key Set that signs the token.
- `JWT_ISSUER`: exact `iss` claim expected on that token.
- `JWT_AUDIENCE`: exact `aud` value expected on that token.

Do not guess these values and do not use a Wix site ID as the audience unless the token/documentation explicitly says so. Wix Headless authentication may expose different token types for different flows; verify which token is intended for your custom backend, its signing keys and claims, and use the stable member identifier from the verified `sub` (or adapt `src/auth.js` to the documented verified claim).

If the token your Wix frontend receives is not a JWT intended for your custom API, do **not** send it here or disable validation. Add a server-side Wix token/session verification adapter based on the official Wix authentication flow. Never trust `memberId` from a request body as proof of identity.

## 3. Run locally

```bash
cp .env.example .env
# Edit .env, especially DATABASE_URL, CORS_ORIGINS, and the JWT values.
npm install
createdb linkchat
psql "$DATABASE_URL" -f schema.sql
npm run dev
```

Health check:

```bash
curl http://localhost:3001/health
```

A healthy database returns `{"status":"ok","database":"ok"}`. This endpoint does not require a login.

### Docker Compose

Set `POSTGRES_PASSWORD` and `CORS_ORIGINS`, `JWT_JWKS_URL`, `JWT_ISSUER`, and `JWT_AUDIENCE` in `.env`, then:

```bash
docker compose up --build -d
docker compose logs -f api
```

For an existing database, apply `schema.sql` yourself; the Compose init script only runs when PostgreSQL creates a fresh data volume.

## 4. API

Every `/api/*` route needs:

```http
Authorization: Bearer <verified-Wix-access-token>
Content-Type: application/json
```

- `GET /api/me` — returns the verified member ID.
- `GET /api/conversations` — conversations the current member belongs to.
- `POST /api/conversations/direct` with `{"memberId":"other-member-id"}` — creates or returns a direct conversation.
- `GET /api/conversations/:id/messages` — latest history page (default 50).
- `POST /api/conversations/:id/messages` with `{"body":"Hello"}` — persists and broadcasts a message.
- `GET /health` — liveness/database check.

Example:

```bash
curl -H "Authorization: Bearer $WIX_ACCESS_TOKEN" \
  http://localhost:3001/api/conversations
```

The `memberId` for a new direct conversation is a target user identifier, not the caller's identity. In a complete product, add a server-side user directory/contact lookup and block/abuse rules before allowing arbitrary users to be messaged.

## 5. Socket.IO client contract

Install `socket.io-client` in your frontend. The client must send the verified token in the handshake:

```js
import { io } from "socket.io-client";

const socket = io("https://YOUR_API_HOST", {
  auth: { token: wixAccessToken }
});

socket.on("connect_error", (err) => console.error(err.message));
socket.on("message:new", (message) => {
  // Add message to the currently open conversation.
});

socket.emit("conversation:join", { conversationId }, (result) => {
  if (!result?.ok) console.error(result?.error);
});

socket.emit("message:send", { conversationId, body: "Hi!" }, (result) => {
  if (!result?.ok) console.error(result?.error);
});
```

Alternatively, send messages with the REST endpoint. Do not send through both methods for the same message or the UI may display duplicates.

## 6. Production checklist

Before opening this to real users:

- Deploy behind HTTPS/WSS and set exact frontend origins in `CORS_ORIGINS`.
- Configure token verification from official Wix documentation and test valid, expired, wrong-issuer, and wrong-audience tokens.
- Add IP/user rate limits, message send throttling, abuse reporting/blocking, and spam controls.
- Add pagination cursors, retention/deletion rules, database backups, monitoring, and migrations.
- Add group chat, unread/read receipts, attachments, push notifications, typing indicators, and moderation only as needed.
- For multiple API instances, configure a Socket.IO adapter (e.g. Redis) and shared rate limits.
- Do not expose PostgreSQL publicly; use managed secrets rather than committing `.env`.
- Decide whether messages should be stored in this PostgreSQL database or Wix CMS. This starter stores chat messages in PostgreSQL; it does not automatically mirror them to Wix CMS.

This is a functional backend starter, not a fully audited production deployment.
