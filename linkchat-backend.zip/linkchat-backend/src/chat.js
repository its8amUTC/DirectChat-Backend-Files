import { pool } from "./db.js";

export async function isConversationMember(conversationId, memberId, db = pool) {
  const result = await db.query(
    `SELECT 1 FROM conversation_members
     WHERE conversation_id = $1 AND member_id = $2`,
    [conversationId, memberId]
  );
  return result.rowCount > 0;
}

export async function listConversations(memberId) {
  const result = await pool.query(
    `SELECT c.id, c.kind, c.created_at, c.updated_at,
            COALESCE(
              json_agg(json_build_object('memberId', cm.member_id))
                FILTER (WHERE cm.member_id IS NOT NULL), '[]'
            ) AS members,
            (SELECT json_build_object('id', m.id, 'senderId', m.sender_id,
                                      'body', m.body, 'createdAt', m.created_at)
             FROM messages m WHERE m.conversation_id = c.id
             ORDER BY m.created_at DESC LIMIT 1) AS last_message
     FROM conversations c
     JOIN conversation_members mine ON mine.conversation_id = c.id
     LEFT JOIN conversation_members cm ON cm.conversation_id = c.id
     WHERE mine.member_id = $1
     GROUP BY c.id
     ORDER BY c.updated_at DESC
     LIMIT 100`,
    [memberId]
  );
  return result.rows;
}

export async function createDirectConversation(memberId, otherMemberId) {
  if (!otherMemberId || typeof otherMemberId !== "string" ||
      otherMemberId.length > 200 || otherMemberId === memberId) {
    const error = new Error("Provide a valid different memberId.");
    error.status = 400;
    throw error;
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Reuse an existing direct conversation with exactly these two participants.
    const existing = await client.query(
      `SELECT c.id
       FROM conversations c
       JOIN conversation_members a ON a.conversation_id = c.id AND a.member_id = $1
       JOIN conversation_members b ON b.conversation_id = c.id AND b.member_id = $2
       WHERE c.kind = 'direct'
         AND (SELECT count(*) FROM conversation_members x WHERE x.conversation_id = c.id) = 2
       LIMIT 1`,
      [memberId, otherMemberId]
    );

    if (existing.rowCount) {
      await client.query("COMMIT");
      return { id: existing.rows[0].id, existing: true };
    }

    const created = await client.query(
      `INSERT INTO conversations(kind) VALUES ('direct') RETURNING id, created_at, updated_at`,
      []
    );
    const conversation = created.rows[0];

    await client.query(
      `INSERT INTO conversation_members(conversation_id, member_id)
       VALUES ($1, $2), ($1, $3)`,
      [conversation.id, memberId, otherMemberId]
    );

    await client.query("COMMIT");
    return { ...conversation, kind: "direct", existing: false };
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

export async function getMessages(conversationId, memberId, limit) {
  if (!(await isConversationMember(conversationId, memberId))) {
    const error = new Error("Conversation not found.");
    error.status = 404;
    throw error;
  }
  const result = await pool.query(
    `SELECT id, conversation_id AS "conversationId", sender_id AS "senderId",
            body, created_at AS "createdAt"
     FROM messages
     WHERE conversation_id = $1
     ORDER BY created_at DESC
     LIMIT $2`,
    [conversationId, limit]
  );
  return result.rows.reverse();
}

export async function sendMessage(conversationId, senderId, body, maxLength) {
  if (typeof body !== "string") {
    const error = new Error("Message body must be text.");
    error.status = 400;
    throw error;
  }
  const normalized = body.trim();
  if (!normalized || normalized.length > maxLength) {
    const error = new Error(`Message must be between 1 and ${maxLength} characters.`);
    error.status = 400;
    throw error;
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const membership = await client.query(
      `SELECT 1 FROM conversation_members
       WHERE conversation_id = $1 AND member_id = $2 FOR SHARE`,
      [conversationId, senderId]
    );
    if (!membership.rowCount) {
      const error = new Error("Conversation not found.");
      error.status = 404;
      throw error;
    }

    const result = await client.query(
      `INSERT INTO messages(conversation_id, sender_id, body)
       VALUES ($1, $2, $3)
       RETURNING id, conversation_id AS "conversationId", sender_id AS "senderId",
                 body, created_at AS "createdAt"`,
      [conversationId, senderId, normalized]
    );
    await client.query(
      `UPDATE conversations SET updated_at = now() WHERE id = $1`,
      [conversationId]
    );
    await client.query("COMMIT");
    return result.rows[0];
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}
