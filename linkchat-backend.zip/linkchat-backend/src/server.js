import "dotenv/config";
import http from "node:http";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import { Server as SocketIOServer } from "socket.io";
import { pool } from "./db.js";
import { bearerTokenFromHeader, verifyAccessToken } from "./auth.js";
import {
  createDirectConversation,
  getMessages,
  isConversationMember,
  listConversations,
  sendMessage
} from "./chat.js";

const PORT = Number(process.env.PORT || 3001);
const MAX_MESSAGE_LENGTH = Math.min(
  Math.max(Number(process.env.MAX_MESSAGE_LENGTH || 4000), 1), 4000
);
const HISTORY_LIMIT = Math.min(
  Math.max(Number(process.env.MESSAGE_HISTORY_LIMIT || 50), 1), 100
);
const allowedOrigins = (process.env.CORS_ORIGINS || "")
  .split(",").map((s) => s.trim()).filter(Boolean);

const app = express();
const server = http.createServer(app);

const corsOptions = {
  origin(origin, callback) {
    // Allow server-to-server/health checks with no Origin; browsers must match allowlist.
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("Origin not allowed by CORS"));
  },
  credentials: false
};

app.disable("x-powered-by");
app.use(helmet());
app.use(cors(corsOptions));
app.use(express.json({ limit: "16kb" }));

const io = new SocketIOServer(server, {
  cors: { origin: allowedOrigins, methods: ["GET", "POST"] },
  maxHttpBufferSize: 16 * 1024
});

async function authenticateToken(token) {
  if (!token) throw new Error("Missing bearer token");
  return verifyAccessToken(token);
}

async function requireAuth(req, res, next) {
  try {
    const token = bearerTokenFromHeader(req.headers.authorization);
    const identity = await authenticateToken(token);
    req.auth = identity;
    next();
  } catch (err) {
    res.status(401).json({ error: "Unauthorized", detail: err.message });
  }
}

app.get("/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ status: "ok", database: "ok" });
  } catch {
    res.status(503).json({ status: "unavailable", database: "error" });
  }
});

app.get("/api/me", requireAuth, (req, res) => {
  res.json({ memberId: req.auth.memberId });
});

app.get("/api/conversations", requireAuth, async (req, res, next) => {
  try {
    res.json({ conversations: await listConversations(req.auth.memberId) });
  } catch (err) { next(err); }
});

app.post("/api/conversations/direct", requireAuth, async (req, res, next) => {
  try {
    const conversation = await createDirectConversation(
      req.auth.memberId, req.body?.memberId
    );
    res.status(conversation.existing ? 200 : 201).json({ conversation });
  } catch (err) { next(err); }
});

app.get("/api/conversations/:id/messages", requireAuth, async (req, res, next) => {
  try {
    const messages = await getMessages(
      req.params.id, req.auth.memberId, HISTORY_LIMIT
    );
    res.json({ messages });
  } catch (err) { next(err); }
});

app.post("/api/conversations/:id/messages", requireAuth, async (req, res, next) => {
  try {
    const message = await sendMessage(
      req.params.id, req.auth.memberId, req.body?.body, MAX_MESSAGE_LENGTH
    );
    io.to(`conversation:${req.params.id}`).emit("message:new", message);
    res.status(201).json({ message });
  } catch (err) { next(err); }
});

// WebSocket authentication: pass { auth: { token: "..." } } from the client.
io.use(async (socket, next) => {
  try {
    const identity = await authenticateToken(socket.handshake.auth?.token);
    socket.data.memberId = identity.memberId;
    next();
  } catch {
    next(new Error("Unauthorized"));
  }
});

io.on("connection", (socket) => {
  socket.on("conversation:join", async (payload, ack = () => {}) => {
    try {
      const conversationId = payload?.conversationId;
      if (typeof conversationId !== "string" || conversationId.length > 100) {
        return ack({ ok: false, error: "Invalid conversationId" });
      }
      const allowed = await isConversationMember(conversationId, socket.data.memberId);
      if (!allowed) return ack({ ok: false, error: "Conversation not found" });

      // Leave other conversation rooms first; join only after server-side membership check.
      for (const room of socket.rooms) {
        if (room.startsWith("conversation:")) socket.leave(room);
      }
      socket.join(`conversation:${conversationId}`);
      ack({ ok: true });
    } catch {
      ack({ ok: false, error: "Could not join conversation" });
    }
  });

  socket.on("message:send", async (payload, ack = () => {}) => {
    try {
      const conversationId = payload?.conversationId;
      const message = await sendMessage(
        conversationId, socket.data.memberId, payload?.body, MAX_MESSAGE_LENGTH
      );
      io.to(`conversation:${conversationId}`).emit("message:new", message);
      ack({ ok: true, message });
    } catch (err) {
      ack({ ok: false, error: err.status ? err.message : "Could not send message" });
    }
  });
});

app.use((err, _req, res, _next) => {
  if (err.message === "Origin not allowed by CORS") {
    return res.status(403).json({ error: "Origin not allowed" });
  }
  console.error(err);
  res.status(err.status || 500).json({
    error: err.status ? err.message : "Internal server error"
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`LinkChat API listening on port ${PORT}`);
});

async function shutdown() {
  io.close();
  server.close(async () => {
    await pool.end();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
