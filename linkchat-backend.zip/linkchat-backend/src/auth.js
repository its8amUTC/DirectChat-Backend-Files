import { createRemoteJWKSet, jwtVerify } from "jose";

const jwksUrl = process.env.JWT_JWKS_URL;
const issuer = process.env.JWT_ISSUER;
const audience = process.env.JWT_AUDIENCE;

let jwks;
if (jwksUrl) {
  const parsed = new URL(jwksUrl);
  if (parsed.protocol !== "https:" && parsed.hostname !== "localhost") {
    throw new Error("JWT_JWKS_URL must use HTTPS outside localhost");
  }
  jwks = createRemoteJWKSet(parsed);
}

export async function verifyAccessToken(token) {
  if (!jwks || !issuer || !audience) {
    throw new Error("JWT verifier is not configured. Set JWT_JWKS_URL, JWT_ISSUER, and JWT_AUDIENCE.");
  }

  const { payload } = await jwtVerify(token, jwks, {
    issuer,
    audience,
    algorithms: ["RS256", "ES256"]
  });

  // The subject must be a stable member identifier from the verified token.
  if (typeof payload.sub !== "string" || payload.sub.length < 1) {
    throw new Error("Verified token is missing a usable subject (sub).");
  }

  return { memberId: payload.sub, claims: payload };
}

export function bearerTokenFromHeader(header = "") {
  const match = /^Bearer\s+(.+)$/i.exec(header);
  return match?.[1];
}
